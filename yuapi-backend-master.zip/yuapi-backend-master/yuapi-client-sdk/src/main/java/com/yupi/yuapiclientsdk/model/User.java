package com.yupi.yuapiclientsdk.model;

import lombok.Data;

/**
 * 用户
 */
@Data
public class User {

    private String username;
}
